const https = require("https");
const querystring = require("querystring");

exports.handler = async (event) => {
  const formData = querystring.parse(event.body);

  // Log submission to Netlify's form log
  console.log("Netlify form submission backup:", formData);

  const postData = querystring.stringify(formData);

  const options = {
    hostname: 'webto.salesforce.com',
    path: '/servlet/servlet.WebToLead?encoding=UTF-8',
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': postData.length
    }
  };

  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      res.on('data', () => {}); // Ignore response body
      res.on('end', () => {
        resolve({
          statusCode: 302,
          headers: {
            Location: formData.retURL || "/thank-you.html"
          },
          body: "Redirecting to thank-you page..."
        });
      });
    });

    req.on('error', (e) => {
      console.error("Salesforce submission failed:", e);
      reject({ statusCode: 500, body: "Error forwarding to Salesforce" });
    });

    req.write(postData);
    req.end();
  });
};
